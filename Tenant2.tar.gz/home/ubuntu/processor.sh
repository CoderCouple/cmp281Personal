#!/bin/bash

#################################################################################
# Author:	Sunil Tiwari							#
# Date: 	10th April 2017							#
# Purpose: 	This shell will be used to execute the cmpe202 personal project #
#	   	through command line and store the generated output in a local	#
#		directory.							#
# Parameters:	name of the input .tar/.zip file				#
# Reference:	https://linuxconfig.org/bash-scripting-tutorial			#
#################################################################################


export OS_HOME=/home/ubuntu
export UNTAR_DIRECTORY=$OS_HOME/UML_Test
export UPLOAD_DIRECTORY=$OS_HOME/localtest/uploads
export BACKUP_DIRECTOTY=$OS_HOME/backup
export INPUT_FILE_NAME=$1
export UMLGRAPH_DIR=$OS_HOME/UMLGraph-5.7_2.23-SNAPSHOT
export PARSE_FILE_NAME=MyUMLOutput
export JAR_FILE_LOCATION=$OS_HOME
export JAR_FILE_NAME=umlparser.jar
export DIR_DELETE=UML_Test_Output
export UML_OUTPUT_DIR=$UNTAR_DIRECTORY/UML_Test_Output
export OUTPUT_FILE_NAME=MyUMLOutput.png

#################################################################################
# Funtion Name:	backup_user_input						#
# Parameters: 	None								#
# Purpose: 	This function will backup the files uploaded by the user and 	#
#	   	store them in the required directory.				#
#										#
#################################################################################


backup_user_input()
{
 echo Entering backup
 cp $UPLOAD_DIRECTORY/$INPUT_FILE_NAME $BACKUP_DIRECTOTY/$INPUT_FILE_NAME.`date +%Y%m%d%H%M%S`
 echo Exiting backup
}


#################################################################################
# Funtion Name:	untar_user_input						#
# Parameters: 	None								#
# Purpose: 	This function will untart the files uploaded by the user and 	#
#	   	store them in the required directory.				#
#										#
#################################################################################


unzip_user_input()
{
 echo Entering unzip
 unzip $UPLOAD_DIRECTORY/$INPUT_FILE_NAME -d $UNTAR_DIRECTORY
 echo Exiting unzip
}


#################################################################################
# Funtion Name:	execute_parser							#
# Parameters: 	None								#
# Purpose: 	This function will execute the .jar file to parse the source  	#
#	   	.java files.							#
#										#
#################################################################################


execute_parser()
{
 echo Entering parser
 $JAVA_HOME/bin/java -jar $JAR_FILE_LOCATION/$JAR_FILE_NAME
 echo Exiting parser
}


#################################################################################
# Funtion Name:	execute_umlgraph_generator					#
# Parameters: 	None								#
# Purpose: 	This function will execute the command to generate the uml  	#
#	   	daigram from the given source files				#
#										#
#################################################################################


execute_umlgraph_generator()
{
 echo Entering UML Graph generator
 cd $UMLGRAPH_DIR
 pwd
 umlgraph $UML_OUTPUT_DIR/$PARSE_FILE_NAME png
 echo exiting UML Graph generator
}

#################################################################################
# Funtion Name:	cleanUp								#
# Parameters: 	None								#
# Purpose: 	This function will remove the java files which have been used  	#
#	   	 to generate the uml diagram					#
#										#
#################################################################################

cleanUp()
{
 echo Entering cleanUp
 cd $UNTAR_DIRECTORY
 pwd
 find $UNTAR_DIRECTORY -maxdepth 1 -type f -delete
 cd $UML_OUTPUT_DIR
 tar -czvf $PARSE_FILE_NAME.tar.gz $OUTPUT_FILE_NAME
 cp $PARSE_FILE_NAME.tar.gz $UPLOAD_DIRECTORY/$PARSE_FILE_NAME.tar.gz
 cd $UNTAR_DIRECTORY
 rm -rf __MACOSX
  
 echo Exiting CleanUp
}



######################
# Main Function Call #
######################

backup_user_input
unzip_user_input
execute_parser
execute_umlgraph_generator
cleanUp


#backup_user_input

#if [ $? != 0 ]
#then
#echo "**************************************************************"
#echo "The command IS NOT EXECUTED SUCCESSFULLY"
#else
#echo "*************************************************************"
#echo 'The command is SUCCESSFULLY executed'
#fi
