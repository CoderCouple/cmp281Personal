/**
*@opt all
*@opt !constructors
 */
class ClassA {
// public attribute via setters and getters
public String message;
private String bark;
public void testMethod()
{ }
}
/**
*@opt all
*@opt !constructors
 */
class ClassB extends ClassA {
private String hello;
}
