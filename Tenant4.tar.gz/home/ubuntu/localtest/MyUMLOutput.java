@startuml
skinparam classAttributeIconSize 0
class Decorator {
+ Decorator(c:Component)
+ operation():String
}
interface Component {
+ operation():String
}
class ConcreteDecoratorA {
- addedState:String
+ ConcreteDecoratorA(c:Component)
+ operation():String
}
class Tester {
+ main(args:String[]):void
}
class ConcreteDecoratorB {
- addedState:String
+ ConcreteDecoratorB(c:Component)
+ operation():String
}
class ConcreteComponent {
+ operation():String
}
Decorator <|-- ConcreteDecoratorA
Decorator <|-- ConcreteDecoratorB
Component -- Decorator
Component <.. Decorator
Component <.. ConcreteDecoratorA
Component <.. Tester
Component <.. ConcreteDecoratorB
Component <|.. Decorator
Component <|.. ConcreteComponent
@enduml
