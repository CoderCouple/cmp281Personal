package gr.spinellis.basic.views;

/**
 * @view
 * 
 * @opt nodefillcolor LightGray
 * @match class gr.spinellis.basic.product.Product
 * @opt attributes
 * @match class gr.spinellis.basic.product.Category
 * @opt nodefillcolor brown
 */
public class ViewChildOverride extends ViewAbstract {
}
