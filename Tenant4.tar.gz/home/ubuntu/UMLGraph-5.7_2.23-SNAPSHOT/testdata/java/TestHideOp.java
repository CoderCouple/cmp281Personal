package test;

/**
 * @hidden
 * @opt operations
 */
class UMLOptions{}

public class TestHideOp {
    /**
     * @hidden
     */
    public void hiddenOperation();
}
