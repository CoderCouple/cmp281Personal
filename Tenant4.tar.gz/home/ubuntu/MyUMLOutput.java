@startuml
skinparam classAttributeIconSize 0
class ConcreteSubject {
- subjectState:String
+ getState():String
+ setState(status:String):void
+ attach(obj:Observer):void
+ detach(obj:Observer):void
+ notifyObservers():void
+ showState():void
}
class TheEconomy {
+ TheEconomy()
}
class ConcreteObserver {
+ ConcreteObserver(theSubject:ConcreteSubject)
+ update():void
+ showState():void
}
interface Observer {
+ update():void
}
class Pessimist {
+ Pessimist(sub:ConcreteSubject)
+ update():void
}
class Optimist {
+ Optimist(sub:ConcreteSubject)
+ update():void
}
interface Subject {
+ attach(obj:Observer):void
+ detach(obj:Observer):void
+ notifyObservers():void
}
ConcreteSubject <|-- TheEconomy
ConcreteObserver <|-- Pessimist
ConcreteObserver <|-- Optimist
Observer "*" -- "1" ConcreteSubject
Observer <.. ConcreteSubject
Subject <|.. ConcreteSubject
Observer <|.. ConcreteObserver
@enduml
