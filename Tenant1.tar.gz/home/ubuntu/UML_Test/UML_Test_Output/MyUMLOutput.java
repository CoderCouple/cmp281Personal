/**
*@opt all
* @assoc 1 - 1 Component
* @depend - <uses> - Component
 */
class Decorator implements Component {
public String operation()
{ }
public Decorator(Component c)
{ }
}
/**
*@opt all
*@opt !constructors
 *@opt inferrel
* @opt inferdep
* @opt inferdepinpackage
 */
interface Component {
public String operation()
;
}
/**
*@opt all
* @depend - <uses> - Component
 */
class ConcreteDecoratorA extends Decorator {
private String addedState;
public String operation()
{ }
public ConcreteDecoratorA(Component c)
{ }
}
/**
*@opt all
*@opt !constructors
* @depend - <uses> - Component
 */
class Tester {
public static void main(String[] args)
{ }
}
/**
*@opt all
* @depend - <uses> - Component
 */
class ConcreteDecoratorB extends Decorator {
private String addedState;
public String operation()
{ }
public ConcreteDecoratorB(Component c)
{ }
}
/**
*@opt all
*@opt !constructors
 */
class ConcreteComponent implements Component {
public String operation()
{ }
}
