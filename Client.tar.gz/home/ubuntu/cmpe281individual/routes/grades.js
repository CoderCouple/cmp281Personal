//"use strict";
//require('use-strict')
var express    = require('express');        // call express
var app        = express();                 // define our app using express
var bodyParser = require('body-parser');
var http = require("http");
var fs = require("fs");
var multer=require("multer");
var path=require("path");
var exec = require('child_process').exec;
var mysql = require('mysql');

//var dbconfig = require('opsworks'); //[1] Include database connection data
var outputString = "";
// RDS refere	nce : http://docs.aws.amazon.com/opsworks/latest/userguide/gettingstarted-node.html

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.engine('html', require('ejs').renderFile);
app.use(express.static('public'));

/*
var pool  = mysql.createPool({
/* host     : 'example.org',
  user     : 'bob',
  password : 'secret',
  database : 'my_db' 

    host: 'mysql.czsdmjbsjpca.us-west-2.rds.amazonaws.com',
    user: 'Sunil28',
    password: 'Sunil#28',
    port: '3306',
    database: 'TenantDB'
});
*/



//var port = process.env.PORT || 8080;     
//var router = express.Router(); 


app.locals.hostname = 'mysql.czsdmjbsjpca.us-west-2.rds.amazonaws.com';
app.locals.username = 'Sunil28';
app.locals.password = 'Sunil#28';
app.locals.port = '3306';
app.locals.database = 'TenantDB';
app.locals.connectionerror = 'successful';
app.locals.databases = '';



var connection = mysql.createConnection({
    host: 'mysql.czsdmjbsjpca.us-west-2.rds.amazonaws.com',
    user: 'Sunil28',
    password: 'Sunil#28',
    port: '3306',
    database: 'TenantDB'
});


/*
//[2] Get database connection data
app.locals.hostname = 'tenantdb.cueqh4kje56l.us-west-2.rds.amazonaws.com';
app.locals.username = 'grader';
app.locals.password = 'grader123';
app.locals.port = '3306';
app.locals.database = 'TenantDB';
app.locals.connectionerror = 'successful';
app.locals.databases = '';



//[3] Connect to the Amazon RDS instance
var connection = mysql.createConnection({
    host: 'tenantdb.cueqh4kje56l.us-west-2.rds.amazonaws.com',
    user: 'grader',
    password: 'grader123',
    port: '3306',
    database: 'TenantDB'
});
*/

connection.connect(function(err)
{
    if (err) {
        app.locals.connectionerror = err.stack;
        return;
    }
});




exports.grades = function(req, res) {

/*var pool  = mysql.createPool({
/* host     : 'example.org',
  user     : 'bob',
  password : 'secret',
  database : 'my_db'
    host: 'mysql.czsdmjbsjpca.us-west-2.rds.amazonaws.com',
    user: 'Sunil28',
    password: 'Sunil#28',
    port: '3306',
    database: 'TenantDB'
});
*/
var tenant=global.tenant;
var grade=req.body.myselect;
console.log(tenant);
console.log(grade);

/*
pool.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
  if (error) throw error;
  console.log('The solution is: ', rows[0].solution);
});
*/

/*
pool.getConnection(function(err, connection) {
  // Use the connection 
  connection.query('SELECT * FROM TENANT1', function (error, results, fields) {
    // And done with the connection. 
    connection.release();
 
    // Handle error after the release. 
    if (error) throw error;
 
    // Don't use the connection here, it has been returned to the pool. 
  });
});
*/
if(tenant.toUpperCase()==="TENANT1")
{
console.log(req.body);
    // var grade ='A';
    var queryString = 'INSERT INTO TENANT1(TENANT_ID, TENANT_GRADE) VALUES('+"'" +tenant + "'" +","+ "'" +grade + "'" + ');';
   //var queryString='SELECT * FROM TENANT1;';
console.log(queryString);
console.log(req.body);
connection.query(queryString, function (err, results) {
    if (err) {
        app.locals.databases = err.stack;
        return res.end("Error Inserting Data, Error:", err.stack);
    }
  connection.end();
return res.end("successfully Inserted.");
});
}




if(tenant.toUpperCase()==="TENANT2")
{
console.log(req.body);
    // var grade ='A';
    var queryString = 'INSERT INTO TENANT2(TENANT_ID, TENANT_GRADE) VALUES('+"'" +tenant + "'" +","+ "'" +grade + "'" + ');';
   //var queryString='SELECT * FROM TENANT1;';
console.log(queryString);
console.log(req.body);
connection.query(queryString, function (err, results) {
    if (err) {
        app.locals.databases = err.stack;
        return res.end("Error Inserting Data, Error:", err.stack);
    }
  connection.end();
return res.end("successfully Inserted.");
});
}




if(tenant.toUpperCase()==="TENANT3")
{
console.log(req.body);
    // var grade ='A';
    var queryString = 'INSERT INTO TENANT3(TENANT_ID, TENANT_GRADE) VALUES('+"'" +tenant + "'" +","+ "'" +grade + "'" + ');';
   //var queryString='SELECT * FROM TENANT1;';
console.log(queryString);
console.log(req.body);
connection.query(queryString, function (err, results) {
    if (err) {
        app.locals.databases = err.stack;
        return res.end("Error Inserting Data, Error:", err.stack);
    }
  connection.end();
return res.end("successfully Inserted.");
});
}



if(tenant.toUpperCase()==="TENANT4")
{
console.log(req.body);
    // var grade ='A';
    var queryString = 'INSERT INTO TENANT4(TENANT_ID, TENANT_GRADE) VALUES('+"'" +tenant + "'" +","+ "'" +grade + "'" + ');';
   //var queryString='SELECT * FROM TENANT1;';
console.log(queryString);
console.log(req.body);
connection.query(queryString, function (err, results) {
    if (err) {
        app.locals.databases = err.stack;
        return res.end("Error Inserting Data, Error:", err.stack);
    }
  connection.end();
return res.end("successfully Inserted.");
});
}


}


