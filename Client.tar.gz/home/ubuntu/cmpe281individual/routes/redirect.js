
/*
 * GET home page.
 */

exports.redirect = function(req, res){
  res.render('redirect.ejs', { title: 'Express' });
};