/*
 * GET home page.
 */
var multer = require('multer');
var exec = require('child_process').exec;
var fs = require('fs');
var request = require('request');
var FormData = require('form-data');

exports.upload = function(req, res) {
    res.render('upload.ejs', {
        title: 'Express'
    });
}

var originaluploadfilename;
var tanent;
exports.upload1 = function(req, res) {

    var storage = multer.diskStorage({
        destination: function(req, file, cb) {
            cb(null, __dirname+'/uploads');
        },
        filename: function(req, file, cb) {
            cb(null, file.originalname);
            originaluploadfilename = file.originalname;
        }

    });
    var upload = multer({
        storage: storage
    }).single('userPhoto');

    upload(req, res, function(err) {
        //console.log(req);
        //console.log(req.body);
        //console.log(req.files);
    	tenant=req.body.fileupload;
        console.log("This is my tanent for which i am uploading the file:" + req.body.fileupload);
        global.tenant=req.body.fileupload;
        console.log(__dirname);
        if (err) {
            return res.end("Error uploading file.");
        }
        res.end("File is uploaded");

        console.log(__dirname);

        console.log(originaluploadfilename);

        var formData = {
            file: fs.createReadStream(__dirname+'/uploads/' + originaluploadfilename)
        };
       
       if(tenant==='tenant1')
       { 
        console.log('Inseide Tenant1')
        request.post({
            url: 'http://applicationloadbalancer-1461392989.us-west-2.elb.amazonaws.com:8090/api/'+tenant,
            formData: formData
        }, function optionalCallback(err, httpResponse, body) {
            if (err) {
                return console.error('upload failed:', err);
            }
            console.log('Upload successful!  Server responded with:', httpResponse.body);

            fs.writeFile(__dirname+'/uploads/' + originaluploadfilename, httpResponse.body, (err) => {
                if (err) throw err;
                console.log('The file has been saved!');
            });
            // fs.writeFile('/home/sunil28/workspace/cmpe281individual/public/'+originaluploadfilename);
        });
        
        }

        if(tenant==='tenant2')
        {
           console.log('Inseide Tenant2')  
            request.post({
            url: 'http://applicationloadbalancer-1461392989.us-west-2.elb.amazonaws.com:8091/api1/'+tenant,
            formData: formData
        }, function optionalCallback(err, httpResponse, body) {
            if (err) {
                return console.error('upload failed:', err);
            }
            console.log('Upload successful!  Server responded with:', httpResponse.body);

            fs.writeFile(__dirname+'/uploads/' + originaluploadfilename, httpResponse.body, (err) => {
                if (err) throw err;
                console.log('The file has been saved!');
            });
            // fs.writeFile('/home/sunil28/workspace/cmpe281individual/public/'+originaluploadfilename);
        }); 
    
          console.log('getting out Tenant2')
  
        }



         if(tenant==='tenant3')
        {
             console.log('Inseide Tenant3')
             request.post({
            url: 'http://applicationloadbalancer-1461392989.us-west-2.elb.amazonaws.com:8092/api2/'+tenant,
            formData: formData
        }, function optionalCallback(err, httpResponse, body) {
            if (err) {
                return console.error('upload failed:', err);
            }
            console.log('Upload successful!  Server responded with:', httpResponse.body);

            fs.writeFile(__dirname+'/uploads/' + originaluploadfilename, httpResponse.body, (err) => {
                if (err) throw err;
                console.log('The file has been saved!');
            });
            // fs.writeFile('/home/sunil28/workspace/cmpe281individual/public/'+originaluploadfilename);
        });

               console.log('Getting Out Tenant3')
        }

        

        if(tenant==='tenant4')
        {
             
                console.log('Inseide Tenant4')
              request.post({
            url: 'http://applicationloadbalancer-1461392989.us-west-2.elb.amazonaws.com:8093/api3/'+tenant,
            formData: formData
        }, function optionalCallback(err, httpResponse, body) {
            if (err) {
                return console.error('upload failed:', err);
            }
            console.log('Upload successful!  Server responded with:', httpResponse.body);

            fs.writeFile(__dirname+'/uploads/' + originaluploadfilename, httpResponse.body, (err) => {
                if (err) throw err;
                console.log('The file has been saved!');
            });
            // fs.writeFile('/home/sunil28/workspace/cmpe281individual/public/'+originaluploadfilename);
        });
                console.log('Getting out  Tenant4')
        }





        /* fs.writeFile(__dirname+'/uploads/MyUMLOutput.png', httpResponse.body, function(err) {
				    if(err) {
				        return console.log(err);
				    }
				    console.log("The file was saved!");
				});*/
         
      /*  request.get({
          url: 'http://localhost:3000/redirect',
        }, function optionalCallback(err, httpResponse, body) {
            if (err) {
               return console.error('upload failed:', err);
            }
            //console.log('Upload successful!  Server responded with:', httpResponse.body);

            //fs.writeFile('/home/sunil28/workspace/cmpe281individual/public/' + originaluploadfilename, httpResponse.body, (err) => {
                if (err) throw err;
                //console.log('The file has been saved!');
            //});
            // fs.writeFile('/home/sunil28/workspace/cmpe281individual/public/'+originaluploadfilename);
       });*/

        console.log(originaluploadfilename);
  /*      const child = exec('/home/sunil28/test.sh',
            function(error, stdout, stderr) {
                console.log('stdout: ' + stdout);
                console.log('stderr: ' + stderr);
                if (error !== null) {
                    console.log('exec error: ' + error);
                }
            });*/

    });


};
