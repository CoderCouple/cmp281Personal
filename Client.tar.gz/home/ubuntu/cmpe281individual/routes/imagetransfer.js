/*
 * GET home page.
 */
var multer = require('multer');
var exec = require('child_process').exec;
var fs = require('fs');
var request = require('request');
var FormData = require('form-data');
var unzip = require ('unzip')

exports.img = function(req, res) {
    res.render('imagetransfer.ejs', {
        title: 'Express'
    });
}


exports.class = function(req, res) {
    res.render('class.ejs', {
        title: 'Express'
    });
}

exports.class2 = function(req, res) {
    res.render('class2.ejs', {
        title: 'Express'
    });
}

exports.class3 = function(req, res) {
    res.render('class3.ejs', {
        title: 'Express'
    });
}


exports.class4 = function(req, res) {
    res.render('class4.ejs', {
        title: 'Express'
    });
}

exports.sequence = function(req, res) {
    res.render('sequence.ejs', {
        title: 'Express'
    });
}


var originaluploadfilename;
var tanent;
exports.imagetransfer = function(req, res) {
	console.log('i am about to render the page.')
	//res.redirect('imagetransfer.ejs');
     console.log('This my global tenant'+global.tenant);
    var storage = multer.diskStorage({
        destination: function(req, file, cb) {
            cb(null, '/home/ubuntu/cmpe281individual/public');
        },
        filename: function(req, file, cb) {
            cb(null, file.originalname);
            originaluploadfilename = file.originalname;
        }

    });

    var upload = multer({
        storage: storage
    }).single('file')


    console.log("This is coming in body" + req.body);
    upload(req, res, function(err) {
        //console.log(req);
        //console.log(req.body);
        //console.log(req.files);
        //console.log("This is my tanent for which i am uploading the file:" + req.body.fileupload);
    //res.sendFile('option.ejs');
        if (err) {
            return res.end("Error uploading file.");
        }
	//res.render('option');
        res.end("File is uploaded");
   //return res.redirect('http://localhost:8090/option.ejs');
        //res.render('option');
    });
     console.log('Unzziping start');    
    const child = exec('tar -xzmvf /home/ubuntu/cmpe281individual/public/MyUMLOutput.tar.gz -C /home/ubuntu/cmpe281individual/public',
            function(error, stdout, stderr) {
                console.log('stdout: ' + stdout);
                console.log('stderr: ' + stderr);
                if (error !== null) {
                    console.log('exec error: ' + error);
                }
            });
 console.log('Unzipping End');

    //fs.createReadStream(__dirname+'/uploads/MyUMLOutput.zip').pipe(unzip.Extract({ path: __dirname+'/uploads' }));
};
