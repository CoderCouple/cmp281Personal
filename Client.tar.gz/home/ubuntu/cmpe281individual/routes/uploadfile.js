
/*
 * GET home page.
 */

exports.upload = function(req, res){
	var storage =   multer.diskStorage({
		  destination: function (req, file, callback) {
		    callback(null, '/home/sunil28/Desktop/FileUpload');
		  },
		  filename: function (req, file, callback) {
		    callback(null, file.fieldname + '-' + Date.now());
		  }
		});
		var upload = multer({ storage : storage}).single('userPhoto');

};