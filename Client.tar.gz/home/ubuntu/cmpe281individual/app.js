
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var upload = require('./routes/upload');
var redirect = require('./routes/redirect');
var imagetransfer = require('./routes/imagetransfer');
var grades = require('./routes/grades');
var http = require('http');
var path = require('path');
var uploadfile = require('./routes/uploadfile');
var bodyParser =    require('body-parser');
var multer  =   require('multer');
var app =   express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.favicon());
app.use(express.logger('dev'));
//app.use(express.bodyParser());
app.use(bodyParser.urlencoded({extended: false}));
app.use(express.methodOverride());
app.use(bodyParser.json());

//app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(app.router);

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', routes.index);
app.get('/users', user.list);
app.get('/upload', upload.upload);
app.post('/api', upload.upload1 );
app.get('/redirect', redirect.redirect);
app.post('/imagetransfer', imagetransfer.imagetransfer);
app.get('/img', imagetransfer.img);
app.get('/class', imagetransfer.class);
app.get('/class2', imagetransfer.class2);
app.get('/class3', imagetransfer.class3);
app.get('/class4', imagetransfer.class4);
app.get('/sequence', imagetransfer.sequence);
app.post('/grades',grades.grades);
http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
