// server.js
// BASE SETUP
// =============================================================================
// call the packages we need
var express = require('express'); // call express
var app = express(); // define our app using express
var bodyParser = require('body-parser');
var http = require('http');
var multer = require('multer');
var fs = require('fs');
var request = require('request');
var exec = require('child_process').exec;
var sleep = require('system-sleep');

//EXPORT MYSQL MODULE
var mysql = require('mysql');


//DATABASE CONNECTION
app.locals.hostname = 'mysql-instance1.czsdmjbsjpca.us-west-2.rds.amazonaws.com';
app.locals.username = 'Sunil28';
app.locals.password = 'Sunil#28';
app.locals.port = '3306';
app.locals.database = 'test';
app.locals.connectionerror = 'successful';
app.locals.databases = '';

var inputfilename;
var originaluploadfilename;
var outputfilaname='MyUMLOutput.png';
var outputimagefile='MyUMLOutput.tar.gz';
//AMAZON RDS CONNECTION
var connection = mysql.createConnection({
    host: 'mysql-instance1.czsdmjbsjpca.us-west-2.rds.amazonaws.com',
    user: 'Sunil28',
    password: 'Sunil#28',
    port: '3306',
    database: 'test'
});


//var mongoose   = require('mongoose');	
//var Users       = require('./app/models/users');
//var client = require('scp2')

// DATABASE CONNECTION
//mongoose.connect('mongodb://localhost/api'); // connect to our database


// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());

var port = process.env.PORT || 8092; // set our port

// ROUTES FOR OUR API
// =============================================================================
var router = express.Router(); // get an instance of the express Router

// middleware to use for all requests
router.use(function(req, res, next) {
    // do logging
    console.log('Something is happening.');
    next(); // make sure we go to the next routes and don't stop here
});

// test route to make sure everything is working (accessed at GET http://localhost:8080/api)
router.get('/', function(req, res) {
    res.json({
        message: 'hooray! welcome to our api!'
    });
});

// more routes for our API will happen here


app.post('/grades',function(req, res) {

 console.log(req.body);
 var grade='A';  
 var queryString = "INSERT INTO TENANT_DATA(TENANT_ID,TANENET_PARAMETER1) VALUES('Tenant1',"+ "'" +grade + "'" + ');';
console.log(req.body);
connection.query(queryString, function (err, results) {
    if (err) {
        app.locals.databases = err.stack;
        return res.end("Error Inserting Data, Error:", err.stack);
    }
  connection.end();
return res.end("Record successfully inserted into the database.");
});
});

// on routes that end in /bears
// ----------------------------------------------------
router.route('/tenant3')

    // get all the bears (accessed at GET http://localhost:8080/api/tenant1)
    .post(function(req, res) {
        console.log("Request body start here !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

//inputfilename=req.file.originalname;
//console.log(req.file.originalname);
        var storage = multer.diskStorage({
            destination: function(req, file, cb) {
                cb(null, __dirname+'/uploads');
            },
            filename: function(req, file, cb) {
                cb(null, file.originalname);
                originaluploadfilename = file.originalname;
            }

        });

        var upload = multer({
            storage: storage
        }).single('file')


        console.log("This is coming in body" + req.body);
        upload(req, res, function(err) {
           // console.log(req);
           // console.log(req.body);
           // console.log(req.file.originalname);
            //console.log(req.body.file.originalname);
           // console.log("This is my tanent for which i am uploading the file:" + req.body.fileupload);
            inputfilename=req.file.originalname;
console.log('1');
console.log(inputfilename);
console.log(originaluploadfilename);
var command = "/home/ubuntu/processor.sh "+inputfilename
console.log(command);
console.log('2');
const child = exec(command, function(error, stdout, stderr) {
                console.log('stdout: ' + stdout);
                console.log('stderr: ' + stderr);
                setTimeout(function2, 3000);
                if (error !== null) {
                    console.log('exec error: ' + error);
                } console.log('3');
                 //setTimeout(function2, 3000);


/* var formData1 = {
            file: fs.createReadStream(__dirname+'/uploads/' + outputimagefile)
        };
         console.log('6');
         console.log('Form Data created');
        request.post({
            url: 'http://applicationloadbalancer-1461392989.us-west-2.elb.amazonaws.com/imagetransfer',
            formData: formData1	
        }, function optionalCallback(err, httpResponse, body) {
            if (err) {
                return console.error('upload failed:', err);
            }console.log('7');
             console.log('about to write the file');
            console.log('Upload successful!  Server responded with:', httpResponse.body);
            console.log(__dirname);

            console.log('8');

            fs.writeFile(__dirname+'/uploads/' + outputimagefile, httpResponse.body, (err) => {
                if (err) throw err;
                console.log('The file has been saved!');
            });
            // fs.writeFile('/home/sunil28/workspace/cmpe281individual/public/'+originaluploadfilename);
        });*/







            });

            if (err) {
                return res.end("Error uploading file.");
            } console.log('4');
        // res.sendFile(__dirname + '/uploads/' +outputfilename);   
	 res.end("File is uploaded");
        });
/*console.log(inputfilename);
console.log(originaluploadfilename);
var command = "/home/ubuntu/processor.sh "+inputfilename 
console.log(command);
const child = exec(command,
            function(error, stdout, stderr) {
                console.log('stdout: ' + stdout);
                console.log('stderr: ' + stderr);
                if (error !== null) {
                    console.log('exec error: ' + error);
                }
            });*/

       // res.redirect('http://applicationloadbalancer-1461392989.us-west-2.elb.amazonaws.com:8090/api/tanent1/option.ejs');
       console.log('5');
           //sleep(2*1000);
        
function function2() { 
        var formData1 = {
            file: fs.createReadStream(__dirname+'/uploads/' + outputimagefile)
        };
         console.log('6');	
         console.log('Form Data created');
        request.post({
            url: 'http://applicationloadbalancer-1461392989.us-west-2.elb.amazonaws.com/imagetransfer',
            formData: formData1
        }, function optionalCallback(err, httpResponse, body) {
            if (err) {
                return console.error('upload failed:', err);
            }console.log('7');
             console.log('about to write the file');
            console.log('Upload successful!  Server responded with:', httpResponse.body);
            console.log(__dirname);

            console.log('8');

            fs.writeFile(__dirname+'/uploads/' + outputimagefile, httpResponse.body, (err) => {
                if (err) throw err;
                console.log('The file has been saved!');
            });
            // fs.writeFile('/home/sunil28/workspace/cmpe281individual/public/'+originaluploadfilename);
        });       


console.log('9');

         console.log(upload);
        console.log("Request body end here !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
}

    });


console.log('10');

// REGISTER OUR ROUTES -------------------------------
// all of our routes will be prefixed with /api
app.use('/api2', router);



// START THE SERVER
// =============================================================================
app.listen(port);
console.log('Magic happens on port ' + port);
