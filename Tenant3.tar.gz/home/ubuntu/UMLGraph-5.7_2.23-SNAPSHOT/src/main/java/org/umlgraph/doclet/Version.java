/* Automatically generated file */
package org.umlgraph.doclet;
class Version { public static String VERSION = "R5_7_2-23-gd0ede4";}
	