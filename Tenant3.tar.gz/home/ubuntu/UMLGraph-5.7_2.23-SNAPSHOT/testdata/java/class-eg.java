
/**
 * @opt nodefillcolor ".13 .9 1"
 * @hidden
 */
class UMLOptions{}

class Person {
	String Name;
}

class Employee extends Person {}

class Client extends Person {}
