package gr.spinellis.iface.views;

/**
 * @view
 *
 * @match class .*
 * @opt hide
 * @match interface gr.spinellis.iface.classes.Face
 * @opt !hide
 * @match class gr.spinellis.iface.classes.Face
 * @opt nodefillcolor lemonchiffon
 */
public class ViewInterfaces {
}


