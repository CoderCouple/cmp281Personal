package gr.spinellis.basic.views;

/**
 * @view
 * @opt hide
 *
 * @match class gr.spinellis.basic.*
 * @opt !hide
 * @opt attributes 
 * @opt nodefontsize 16 
 * @opt nodefillcolor yellow
 */
public class ViewAtt {
}
